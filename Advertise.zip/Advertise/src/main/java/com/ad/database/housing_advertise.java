package com.ad.database;

import lombok.Data;

@Data
public class housing_advertise {
    private int id;
    private Integer hid;
    private Integer aid;
}
